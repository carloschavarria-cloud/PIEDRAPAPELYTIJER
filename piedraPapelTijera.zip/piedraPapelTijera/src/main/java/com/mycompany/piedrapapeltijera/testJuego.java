package com.mycompany.piedrapapeltijera;

public class testJuego {
    public static void main(String[] args){
      

    PiedraPapelTijera juego = new PiedraPapelTijera();
    int j1 = juego.getMano();
    int j2 = juego.getMano();
    
    System.out.println("Jugador 1:" + juego.valor(j1));
    System.out.println("Jugador 2:" + juego.valor(j2));
    
    System.out.println(juego.ganador(j1, j2));
}}

